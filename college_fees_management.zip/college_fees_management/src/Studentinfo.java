import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class Studentinfo extends JFrame {
	
	Connection cn=null;
	Statement st=null;
	Database db=new Database();
	String result = db.Connectdb();
	java.sql.PreparedStatement pst=null;

	private JPanel contentPane;
	private JTextField Student_ID;
	private JTextField Email_ID;
	private JTextField Caste;
	private JTextField Student_Name;
	private JTextField Phone_No;
	private JTextField Entry_Year;
	private JLabel STUDENT_ID_2;
	private JLabel EMAIL_ID_1;
	private JLabel PHONE_NO_1;
	private JLabel DEGREE_1;
	private JLabel SEMESTER_1;
	private JLabel CASTE_1;
	private JButton Cancel_1;
	private JButton btnEditFeesDetails;

	
	
	
	String cat1="";
	String cat2="";
	String degree;
	String gender;
	private JComboBox semester;
	private JRadioButton M;
	private JRadioButton F;
	private JRadioButton rd1;
	private JRadioButton rd2;
	private JButton delete_1;
	private JButton Home;
	
	


	
	private void auto_id()

	{

		try

		{

			long id=0;

			

			

			Class.forName("com.mysql.jdbc.Driver");

            cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");

            st=cn.createStatement();

            String sql ="select * from students_registration";

            pst = cn.prepareStatement(sql);

            ResultSet rs=st.executeQuery(sql);

            

            while(rs.next()) {

            	id=Long.parseLong(rs.getString("STUDENT_ID"));

            }

            id++;

            Student_ID.setText(String.valueOf(id));

		}

		catch(Exception ex)

		{

			JOptionPane.showMessageDialog(null,ex.toString());

		}

	}


	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Studentinfo frame = new Studentinfo();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Studentinfo() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 631);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(95, 158, 160));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("STUDENT DEATILS");
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 21));
		lblNewLabel.setBounds(296, 64, 197, 46);
		contentPane.add(lblNewLabel);
		
		STUDENT_ID_2 = new JLabel("  Student ID:");
		STUDENT_ID_2.setFont(new Font("Serif", Font.BOLD, 17));
		STUDENT_ID_2.setBounds(10, 124, 138, 46);
		contentPane.add(STUDENT_ID_2);
		
		DEGREE_1 = new JLabel("  Degree Program:");
		DEGREE_1.setFont(new Font("Serif", Font.BOLD, 17));
		DEGREE_1.setBounds(10, 250, 150, 46);
		contentPane.add(DEGREE_1);
		
		JLabel STUDENT_NAME_1 = new JLabel("Student_Name:");
		STUDENT_NAME_1.setFont(new Font("Serif", Font.BOLD, 17));
		STUDENT_NAME_1.setBounds(388, 120, 138, 46);
		contentPane.add(STUDENT_NAME_1);
		
		EMAIL_ID_1 = new JLabel("Email ID:");
		EMAIL_ID_1.setFont(new Font("Serif", Font.BOLD, 17));
		EMAIL_ID_1.setBounds(20, 180, 84, 46);
		contentPane.add(EMAIL_ID_1);
		
		PHONE_NO_1 = new JLabel("Phone No.");
		PHONE_NO_1.setFont(new Font("Serif", Font.BOLD, 17));
		PHONE_NO_1.setBounds(388, 180, 138, 46);
		contentPane.add(PHONE_NO_1);
		
		SEMESTER_1 = new JLabel("Semester:");
		SEMESTER_1.setFont(new Font("Serif", Font.BOLD, 17));
		SEMESTER_1.setBounds(388, 250, 138, 46);
		contentPane.add(SEMESTER_1);
		
		JLabel GENDER_1 = new JLabel("  Gender:");
		GENDER_1.setFont(new Font("Serif", Font.BOLD, 17));
		GENDER_1.setBounds(10, 322, 138, 46);
		contentPane.add(GENDER_1);
		
		CASTE_1 = new JLabel("  Caste:");
		CASTE_1.setFont(new Font("Serif", Font.BOLD, 17));
		CASTE_1.setBounds(388, 402, 120, 36);
		contentPane.add(CASTE_1);
		
		JLabel ENTRY_YEAR_1 = new JLabel("Entry Year:");
		ENTRY_YEAR_1.setFont(new Font("Serif", Font.BOLD, 17));
		ENTRY_YEAR_1.setBounds(388, 322, 102, 46);
		contentPane.add(ENTRY_YEAR_1);
		
		Student_ID = new JTextField();
		Student_ID.setBackground(new Color(192, 192, 192));
		Student_ID.setBounds(158, 141, 90, 19);
		contentPane.add(Student_ID);
		Student_ID.setColumns(10);
		
		Email_ID = new JTextField();
		Email_ID.setBackground(new Color(192, 192, 192));
		Email_ID.setColumns(10);
		Email_ID.setBounds(158, 197, 188, 19);
		contentPane.add(Email_ID);
		
		Caste = new JTextField();
		Caste.setColumns(10);
		Caste.setBackground(Color.LIGHT_GRAY);
		Caste.setBounds(512, 414, 188, 19);
		contentPane.add(Caste);
		
		Student_Name = new JTextField();
		Student_Name.setColumns(10);
		Student_Name.setBackground(Color.LIGHT_GRAY);
		Student_Name.setBounds(512, 141, 188, 19);
		contentPane.add(Student_Name);
		
		Phone_No = new JTextField();
		Phone_No.setColumns(10);
		Phone_No.setBackground(Color.LIGHT_GRAY);
		Phone_No.setBounds(512, 197, 188, 19);
		contentPane.add(Phone_No);
		
		Entry_Year = new JTextField();
		Entry_Year.setColumns(10);
		Entry_Year.setBackground(Color.LIGHT_GRAY);
		Entry_Year.setBounds(512, 339, 188, 19);
		contentPane.add(Entry_Year);
		
		JButton Update = new JButton("Update");
		Update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					if(rd1.isSelected())

					{

						cat1="B.ED";

					}

					if(rd2.isSelected())

					{

						cat1="D.ED";

					}

					if(M.isSelected())

					{

						cat2="Male";

						}

					if(F.isSelected())

					{

						cat2="Female";

					}
					
				String STUDENT_ID=Student_ID.getText();
				String EMAIL_ID=Email_ID.getText();
				String CASTE=Caste.getText();
				String STUDENT_NAME=Student_Name.getText();
				String PHONE_NO=Phone_No.getText();
				String SEMESTER= semester.getSelectedItem().toString();
				String ENTRY_YEAR=Entry_Year.getText();
			
				String update= db.update("update students_registration set STUDENT_ID='"+STUDENT_ID+"',STUDENT_NAME='"+STUDENT_NAME+"',EMAIL_ID='"+EMAIL_ID+"',PHONE_NO='"+PHONE_NO+"',DEGREE='"+cat1+"',SEMESTER='"+SEMESTER+"',GENDER='"+cat2+"',ENTRY_YEAR='"+ENTRY_YEAR+"',CASTE='"+CASTE+"' where STUDENT_ID='"+STUDENT_ID+"' ");
				JOptionPane.showMessageDialog(null, update);
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, ex.toString());
				}
			}
		});
		Update.setForeground(SystemColor.info);
		Update.setBackground(new Color(0, 0, 0));
		Update.setFont(new Font("Serif", Font.BOLD, 18));
		Update.setBounds(103, 510, 96, 36);
		contentPane.add(Update);
		
		delete_1 = new JButton("Delete");
		delete_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				try 
				{
					String stud_id = Student_ID.getText();
					String delete=db.delete("delete from students_registration where STUDENT_ID='"+stud_id+"' ");
					JOptionPane.showMessageDialog(null, delete);
				}
				catch(Exception ex) {
					JOptionPane.showMessageDialog(null, ex.toString());
				}
			}
		});
		delete_1.setForeground(new Color(255, 255, 255));
		delete_1.setBackground(new Color(0, 0, 0));
		delete_1.setFont(new Font("Serif", Font.BOLD, 18));
		delete_1.setBounds(296, 510, 90, 36);
		contentPane.add(delete_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.inactiveCaption);
		panel_1.setBounds(20, 10, 73, 50);
		contentPane.add(panel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.inactiveCaption);
		panel.setBounds(103, 10, 598, 50);
		contentPane.add(panel);
		
		Cancel_1 = new JButton("Back");
		Cancel_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IYearList obj=new IYearList();
				obj.setVisible(true);
			}
		});
		Cancel_1.setForeground(Color.WHITE);
		Cancel_1.setFont(new Font("Serif", Font.BOLD, 18));
		Cancel_1.setBackground(new Color(0, 0, 0));
		Cancel_1.setBounds(467, 510, 90, 36);
		contentPane.add(Cancel_1);
		
		btnEditFeesDetails = new JButton("Edit Fees Details");
		btnEditFeesDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fee_Details obj=new Fee_Details();
				obj.setVisible(true);
			}
		});
		btnEditFeesDetails.setForeground(new Color(0, 0, 0));
		btnEditFeesDetails.setFont(new Font("Serif", Font.BOLD, 17));
		btnEditFeesDetails.setBackground(new Color(255, 255, 255));
		btnEditFeesDetails.setBounds(478, 474, 197, 25);
		contentPane.add(btnEditFeesDetails);
		
		rd1 = new JRadioButton("B.ED");
		rd1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rd1.isSelected()) {
				degree="B.ED";
				rd2.setSelected(false);
					
				}
			}
		});
		rd1.setFont(new Font("Serif", Font.BOLD, 15));
		rd1.setBackground(Color.LIGHT_GRAY);
		rd1.setBounds(160, 264, 73, 21);
		contentPane.add(rd1);
		
		rd2 = new JRadioButton("D.ED");
		rd2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rd2.isSelected()) {
					degree="D.ED";
					rd1.setSelected(false);
						
					}
			}
		});
		rd2.setFont(new Font("Serif", Font.BOLD, 15));
		rd2.setBackground(Color.LIGHT_GRAY);
		rd2.setBounds(256, 264, 73, 21);
		contentPane.add(rd2);
		
		M = new JRadioButton("Male");
		M.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(M.isSelected()) {
					gender="Male";
					F.setSelected(false);
						
					}
			}
		});
					
		M.setFont(new Font("Serif", Font.BOLD, 15));
		M.setBackground(Color.LIGHT_GRAY);
		M.setBounds(154, 338, 73, 21);
		contentPane.add(M);
		
		F = new JRadioButton("Female");
		F.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(F.isSelected()) {
					gender="Female";
					M.setSelected(false);
						
					}
			}
		});
		
		F.setFont(new Font("Serif", Font.BOLD, 15));
		F.setBackground(Color.LIGHT_GRAY);
		F.setBounds(256, 338, 88, 21);
		contentPane.add(F);
		
		semester = new JComboBox();
		semester.setFont(new Font("Serif", Font.PLAIN, 16));
		semester.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		semester.setModel(new DefaultComboBoxModel(new String[] {"Sem-I", "Sem-II", "Sem-III", "Sem-IV"}));
		semester.setBounds(512, 266, 188, 21);
		contentPane.add(semester);
		
		JButton btnNewButton = new JButton("search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try

		          {

					 
				      String id=Student_ID.getText();
				      String name=Student_Name.getText();

					  
				      Class.forName("com.mysql.jdbc.Driver");

		              cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");

		              st=cn.createStatement();

		              String sql = "select * from students_registration where STUDENT_ID = '"+id+"'  or STUDENT_NAME='"+name+"'";

		              ResultSet rs=st.executeQuery(sql);
		         

		              while(rs.next())

		              {

		                 Student_ID.setText(rs.getString("STUDENT_ID"));

		                  Student_Name.setText(rs.getString("STUDENT_NAME"));

		                  Email_ID.setText(rs.getString("EMAIL_ID"));

		                  Phone_No.setText(rs.getString("PHONE_NO"));

		                  Entry_Year.setText(rs.getString("ENTRY_YEAR"));

		                  Caste.setText(rs.getString("CASTE"));

		                  if(rs.getString("DEGREE").equals("B.ED")) {
		                	  rd1.setSelected(true);
		                  }
		                  else if(rs.getString("DEGREE").equals("D.ED")) {
		                	  rd2.setSelected(true);
		                  }
		                  if(rs.getString("GENDER").equals("Male")) {
		                	  M.setSelected(true);
		                  }
		                  else if(rs.getString("GENDER").equals("Female")) {
		                	  F.setSelected(true);
		                  }
		                
		                

		                  

		              }

		          }

			
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, ex.toString());
				}

			}
		});
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 16));
		btnNewButton.setBounds(245, 141, 84, 21);
		contentPane.add(btnNewButton);
		
		Home = new JButton("Home");
		Home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		Home.setForeground(Color.WHITE);
		Home.setFont(new Font("Serif", Font.BOLD, 15));
		Home.setBackground(Color.BLACK);
		Home.setBounds(627, 78, 73, 23);
		contentPane.add(Home);
		auto_id();
	}
}
