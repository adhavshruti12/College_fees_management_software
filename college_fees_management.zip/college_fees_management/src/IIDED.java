import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import net.proteanit.sql.DbUtils;
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class IIDED extends JFrame {

	private JPanel contentPane;
	private JTextField Student_ID;
	private JTable table;
	
	private JComboBox Year_Box;
	
	Connection cn=null;
	Statement st=null;
	Database db=new Database();
	java.sql.PreparedStatement pst=null;
	String result=db.Connectdb();
	
	private void table_data()

	{

		try

		{

			Class.forName("com.mysql.jdbc.Driver");

            cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");

            st=cn.createStatement();

            String sql ="select * from students_registration where DEGREE='D.ED' && (SEMESTER = 'Sem-III' || SEMESTER = 'Sem-IV') ";

            pst = cn.prepareStatement(sql);

            ResultSet rs=st.executeQuery(sql);

            table.setModel(DbUtils.resultSetToTableModel(rs));

		}

		catch(Exception ex)

		{

			JOptionPane.showMessageDialog(null,ex.toString());

		}

	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					IIDED frame = new IIDED();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public IIDED() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 740, 639);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(95, 158, 160));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.inactiveCaption);
		panel_1.setBounds(24, 10, 73, 50);
		contentPane.add(panel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.inactiveCaption);
		panel.setBounds(112, 10, 597, 50);
		contentPane.add(panel);
		
		Student_ID = new JTextField();
		Student_ID.setBackground(new Color(192, 192, 192));
		Student_ID.setFont(new Font("Serif", Font.PLAIN, 12));
		Student_ID.setColumns(10);
		Student_ID.setBounds(112, 94, 183, 23);
		contentPane.add(Student_ID);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		btnBack.setForeground(Color.WHITE);
		btnBack.setFont(new Font("Serif", Font.BOLD, 15));
		btnBack.setBackground(new Color(0, 0, 0));
		btnBack.setBounds(584, 409, 73, 23);
		contentPane.add(btnBack);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(38, 214, 640, 162);
		contentPane.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				"New column", "New column", "New column"
			}
		));
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student_Register obj=new Student_Register();
				obj.setVisible(true);
				table_data();

			}
		});
		btnAdd.setForeground(Color.WHITE);
		btnAdd.setFont(new Font("Serif", Font.BOLD, 15));
		btnAdd.setBackground(new Color(0, 0, 0));
		btnAdd.setBounds(584, 170, 73, 23);
		contentPane.add(btnAdd);
		
		JButton btnNewButton = new JButton("search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try

				{

					Class.forName("com.mysql.jdbc.Driver");

		            cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");

		            st=cn.createStatement();

		            String sql ="select * from students_registration where DEGREE='D.ED' && (STUDENT_ID='"+Student_ID.getText()+"' || ENTRY_YEAR = '"+Year_Box.getSelectedItem()+"') && (SEMESTER = 'Sem-III' || SEMESTER = 'Sem-IV') ";

		            pst = cn.prepareStatement(sql);

		            ResultSet rs=st.executeQuery(sql);

		            table.setModel(DbUtils.resultSetToTableModel(rs));

				}

				catch(Exception ex)

				{

					JOptionPane.showMessageDialog(null,ex.toString());

				}
			}
		});
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 16));
		btnNewButton.setBounds(421, 94, 84, 21);
		contentPane.add(btnNewButton);
		
		JComboBox Year_Box = new JComboBox();
		Year_Box.setModel(new DefaultComboBoxModel(new String[] {"Years", "2020", "2021", "2022", "2023", "2024"}));
		Year_Box.setFont(new Font("Serif", Font.BOLD, 16));
		Year_Box.setBounds(319, 94, 92, 21);
		contentPane.add(Year_Box);
		
		JButton Home = new JButton("Home");
		Home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		Home.setForeground(Color.WHITE);
		Home.setFont(new Font("Serif", Font.BOLD, 15));
		Home.setBackground(Color.BLACK);
		Home.setBounds(636, 70, 73, 23);
		contentPane.add(Home);
		table_data();

		
	}
}
