import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Fee_Details extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField Remaining_Fees;
	private JTextField Total_Fees;
	private JTextField Paid_Fees;
	private JTextField Installment_No;
	private JTextField Student_ID;
	private JTextField Student_Name;
	private JTextField Fee_ID;
	
	java.sql.PreparedStatement pst=null;

	
	Connection cn=null;
	Statement st=null;
	Database db=new Database();
	String result=db.Connectdb();
	private JLabel trext_field;
	private JTextField Pay_Amount;
	/**
	 * Launch the application.
	 */
	
	private void auto_id()

	{

		try

		{

			long id=0;

			

			

			Class.forName("com.mysql.jdbc.Driver");

            cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");

            st=cn.createStatement();

            String sql ="select * from fee_details";

            pst = cn.prepareStatement(sql);

            ResultSet rs=st.executeQuery(sql);

            

            while(rs.next()) {

            	id=Long.parseLong(rs.getString("Fee_ID"));

            }

            id++;

            Fee_ID.setText(String.valueOf(id));

		}

		catch(Exception ex)

		{

			JOptionPane.showMessageDialog(null,ex.toString());

		}

	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Fee_Details frame = new Fee_Details();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Fee_Details() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 797, 625);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(95, 158, 160));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.inactiveCaption);
		panel_1.setBounds(20, 10, 73, 50);
		contentPane.add(panel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.inactiveCaption);
		panel.setBounds(110, 10, 650, 50);
		contentPane.add(panel);
		
		table = new JTable();
		table.setBounds(274, 343, -204, -154);
		contentPane.add(table);
		
		JLabel REMAINING_FEES_1 = new JLabel("Remaining Fees:");
		REMAINING_FEES_1.setFont(new Font("Serif", Font.BOLD, 17));
		REMAINING_FEES_1.setBounds(428, 326, 138, 46);
		contentPane.add(REMAINING_FEES_1);
		
		Remaining_Fees = new JTextField();
		Remaining_Fees.setColumns(10);
		Remaining_Fees.setBackground(Color.LIGHT_GRAY);
		Remaining_Fees.setBounds(572, 343, 188, 19);
		contentPane.add(Remaining_Fees);
		
		JLabel TOTAL_FEES_1 = new JLabel("Total Fees:");
		TOTAL_FEES_1.setFont(new Font("Serif", Font.BOLD, 17));
		TOTAL_FEES_1.setBounds(49, 260, 138, 46);
		contentPane.add(TOTAL_FEES_1);
		
		JLabel PAID_FEES_1 = new JLabel("Paid Fees:");
		PAID_FEES_1.setFont(new Font("Serif", Font.BOLD, 17));
		PAID_FEES_1.setBounds(428, 266, 138, 34);
		contentPane.add(PAID_FEES_1);
		
		Total_Fees = new JTextField();
		Total_Fees.setColumns(10);
		Total_Fees.setBackground(Color.LIGHT_GRAY);
		Total_Fees.setBounds(197, 277, 188, 19);
		contentPane.add(Total_Fees);
		
		Paid_Fees = new JTextField();
		Paid_Fees.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				double total_fees= Double.parseDouble(Total_Fees.getText());
				double paid_fees= Double.parseDouble(Paid_Fees.getText());
				double pay=Double.parseDouble(Pay_Amount.getText());
				double remaining_fees = total_fees - paid_fees-pay;
				Remaining_Fees.setText(String.valueOf(remaining_fees));
				
				
			}
		});
		Paid_Fees.setColumns(10);
		Paid_Fees.setBackground(Color.LIGHT_GRAY);
		Paid_Fees.setBounds(572, 277, 188, 19);
		contentPane.add(Paid_Fees);
		
		JLabel lblFeesDetails = new JLabel("FEES DETAILS");
		lblFeesDetails.setFont(new Font("Serif", Font.BOLD, 21));
		lblFeesDetails.setBounds(324, 66, 178, 46);
		contentPane.add(lblFeesDetails);
		
		JButton add = new JButton("Add");
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					String FEE_ID=Fee_ID.getText();
					String STUDENT_ID=Student_ID.getText();
					String STUDENT_NAME=Student_Name.getText();
					String INSTALLMENT_NO=Installment_No.getText();
					String TOTAL_FEES=Total_Fees.getText();
					String PAID_FEES=Paid_Fees.getText();
					String REMAINING_FEES=Remaining_Fees.getText();
					String PAY_AMOUNT=Pay_Amount.getText();
					
					double fees_paid = Double.parseDouble(PAID_FEES) + Double.parseDouble(PAY_AMOUNT);
					
					
				String insert= db.Insert("insert into fee_details(Fee_ID, STUDENT_ID, STUDENT_NAME, INSTALLMENT_NO, TOTAL_FEES, PAID_FEES, REMAINING_FEES,PAY_AMOUNT) values('"+FEE_ID+"','"+STUDENT_ID+"','"+STUDENT_NAME+"','"+INSTALLMENT_NO+"','"+TOTAL_FEES+"','"+REMAINING_FEES+"','"+fees_paid+"','"+PAY_AMOUNT+"')");
				JOptionPane.showMessageDialog(null, insert);
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, ex.toString());
				}
			}
		});
		add.setForeground(SystemColor.info);
		add.setFont(new Font("Serif", Font.BOLD, 18));
		add.setBackground(new Color(0, 0, 0));
		add.setBounds(49, 492, 90, 33);
		contentPane.add(add);
		
		JButton Update = new JButton("Update");
		Update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
try {
					
					String FEE_ID=Fee_ID.getText();
					String STUDENT_ID=Student_ID.getText();
					String STUDENT_NAME=Student_Name.getText();
					String INSTALLMENT_NO=Installment_No.getText();
					String TOTAL_FEES=Total_Fees.getText();
					String PAID_FEES=Paid_Fees.getText();
					String REMAINING_FEES=Remaining_Fees.getText();
					
					
				String update= db.update("insert into fee_details(Fee_ID, STUDENT_ID, STUDENT_NAME, INSTALLMENT_NO, TOTAL_FEES, PAID_FEES, REMAINING_FEES) values('"+FEE_ID+"','"+STUDENT_ID+"','"+STUDENT_NAME+"','"+INSTALLMENT_NO+"','"+TOTAL_FEES+"','"+REMAINING_FEES+"','"+PAID_FEES+"')");
				JOptionPane.showMessageDialog(null, update);
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, ex.toString());
				}
			}
		});
		Update.setForeground(SystemColor.info);
		Update.setFont(new Font("Serif", Font.BOLD, 18));
		Update.setBackground(new Color(0, 0, 0));
		Update.setBounds(222, 492, 96, 33);
		contentPane.add(Update);
		
		JButton Cancel = new JButton("Delete");
		Cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try



				{

                 String stud_id = Student_ID.getText();

                String delete=db.delete("delete from fee_details where STUDENT_ID='"+stud_id+"' ");

              JOptionPane.showMessageDialog(null, delete);

	}


catch(Exception ex) {


JOptionPane.showMessageDialog(null, ex.toString());



				}
			}
		});
		Cancel.setForeground(Color.WHITE);
		Cancel.setFont(new Font("Serif", Font.BOLD, 18));
		Cancel.setBackground(new Color(0, 0, 0));
		Cancel.setBounds(412, 492, 90, 33);
		contentPane.add(Cancel);
		
		JButton Back = new JButton("Back");
		Back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Studentinfo obj=new Studentinfo();
				obj.setVisible(true);
			}
		});
		Back.setForeground(Color.WHITE);
		Back.setFont(new Font("Serif", Font.BOLD, 18));
		Back.setBackground(new Color(0, 0, 0));
		Back.setBounds(581, 491, 90, 34);
		contentPane.add(Back);
		
		JLabel STUDENT_ID_2 = new JLabel("    Student ID:");
		STUDENT_ID_2.setFont(new Font("Serif", Font.BOLD, 17));
		STUDENT_ID_2.setBounds(32, 180, 116, 46);
		contentPane.add(STUDENT_ID_2);
		
		JLabel STUDENT_NAME_1 = new JLabel("Student_Name:");
		STUDENT_NAME_1.setFont(new Font("Serif", Font.BOLD, 17));
		STUDENT_NAME_1.setBounds(414, 180, 138, 46);
		contentPane.add(STUDENT_NAME_1);
		
		JLabel STUDENT_NAME_1_1 = new JLabel("Fee_ID:");
		STUDENT_NAME_1_1.setFont(new Font("Serif", Font.BOLD, 17));
		STUDENT_NAME_1_1.setBounds(49, 112, 73, 46);
		contentPane.add(STUDENT_NAME_1_1);
		
		Installment_No = new JTextField();
		Installment_No.setColumns(10);
		Installment_No.setBackground(Color.LIGHT_GRAY);
		Installment_No.setBounds(546, 129, 123, 19);
		contentPane.add(Installment_No);
		
		Student_ID = new JTextField();
		Student_ID.setColumns(10);
		Student_ID.setBackground(Color.LIGHT_GRAY);
		Student_ID.setBounds(195, 197, 61, 19);
		contentPane.add(Student_ID);
		
		Student_Name = new JTextField();
		Student_Name.setColumns(10);
		Student_Name.setBackground(Color.LIGHT_GRAY);
		Student_Name.setBounds(546, 197, 188, 19);
		contentPane.add(Student_Name);
		
		JLabel STUDENT_NAME_1_2 = new JLabel("Installment No.:");
		STUDENT_NAME_1_2.setFont(new Font("Serif", Font.BOLD, 17));
		STUDENT_NAME_1_2.setBounds(412, 112, 138, 46);
		contentPane.add(STUDENT_NAME_1_2);
		
		Fee_ID = new JTextField();
		Fee_ID.setColumns(10);
		Fee_ID.setBackground(Color.LIGHT_GRAY);
		Fee_ID.setBounds(195, 129, 61, 19);
		contentPane.add(Fee_ID);
		
		JButton btnNewButton = new JButton("search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try

		          {

					 
				      String id=Student_ID.getText();
				      String name=Student_Name.getText();

					  
				      Class.forName("com.mysql.jdbc.Driver");

		              cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");

		              st=cn.createStatement();

		              String sql = "select * from students_registration where STUDENT_ID = '"+id+"'  or STUDENT_NAME='"+name+"'" ;

		              ResultSet rs=st.executeQuery(sql);

		              while(rs.next())

		              {
		                

		                  Total_Fees.setText(rs.getString("TOTAL_FEES"));

		                  Student_Name.setText(rs.getString("STUDENT_NAME"));

		                

		                  

		              }
		              rs.close();
		              
		              sql = "select * from students_registration where STUDENT_ID = '"+id+"'" ;
		              rs=st.executeQuery(sql);
		              while(rs.next())

		              {
		                

		                  Paid_Fees.setText(rs.getString("PAID_FEES"));

		                

		                

		                  

		              }
		              

		          }

			
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, ex.toString());
				}

			}
		});
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 16));
		btnNewButton.setBounds(255, 195, 84, 19);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("search");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try

		          {

					 
				      String id=Fee_ID.getText();
				    //  String name=Student_Name.getText();

					  
				      Class.forName("com.mysql.jdbc.Driver");

		              cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");

		              st=cn.createStatement();

		              String sql = "select * from fee_details where FEE_ID = '"+id+"'" ;

		              ResultSet rs=st.executeQuery(sql);

		              while(rs.next())

		              {
		                 Student_ID.setText(rs.getString("STUDENT_ID"));
		                 Student_Name.setText(rs.getString("STUDENT_NAME"));

		                 Installment_No.setText(rs.getString("INSTALLMENT_NO"));
                            
		                  Total_Fees.setText(rs.getString("TOTAL_FEES"));
		                  Remaining_Fees.setText(rs.getString("REMAINING_FEES"));
		                  Paid_Fees.setText(rs.getString("PAID_FEES"));
		                  Pay_Amount.setText(rs.getString("PAY_AMOUNT"));
		                  

		                

		                  

		              }

		          }

			
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, ex.toString());
				}

			}
		});
		btnNewButton_1.setFont(new Font("Serif", Font.BOLD, 16));
		btnNewButton_1.setBounds(255, 127, 84, 19);
		contentPane.add(btnNewButton_1);
		
		trext_field = new JLabel("Pay Amount:");
		trext_field.setFont(new Font("Serif", Font.BOLD, 17));
		trext_field.setBounds(49, 316, 138, 46);
		contentPane.add(trext_field);
		
		Pay_Amount = new JTextField();
		Pay_Amount.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				double total_fees= Double.parseDouble(Total_Fees.getText());
				double paid_fees= Double.parseDouble(Paid_Fees.getText());
				double pay=Double.parseDouble(Pay_Amount.getText());
				double remaining_fees = total_fees - paid_fees-pay;
				Remaining_Fees.setText(String.valueOf(remaining_fees));
			}
		});
		Pay_Amount.setColumns(10);
		Pay_Amount.setBackground(Color.LIGHT_GRAY);
		Pay_Amount.setBounds(197, 343, 188, 19);
		contentPane.add(Pay_Amount);
		
		JButton Home = new JButton("Home");
		Home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		Home.setForeground(Color.WHITE);
		Home.setFont(new Font("Serif", Font.BOLD, 15));
		Home.setBackground(Color.BLACK);
		Home.setBounds(687, 80, 73, 23);
		contentPane.add(Home);
		auto_id();
	}
}
