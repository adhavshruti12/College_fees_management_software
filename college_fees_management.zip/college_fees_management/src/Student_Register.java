import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JList;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Student_Register extends JFrame {

	private JPanel contentPane;
	private JTextField Student_ID;
	private JTextField Email_ID;
	private JTextField Caste;
	private JTextField Student_Name;
	private JTextField Phone_No;
	private JTextField Entry_Year;
	private JLabel STUDENT_ID_2;
	private JLabel EMAIL_ID_1;
	private JLabel PHONE_NO_1;
	private JLabel DEGREE_1;
	private JLabel SEMESTER_1;
	private JLabel CASTE_1;
	private JComboBox semester;
	
	private JRadioButton rd1;
	private JRadioButton rd2;
	private JRadioButton M;
	private JRadioButton F;
	
	Connection cn=null;
	Statement st=null;
	Database db=new Database();
	String result=db.Connectdb();
	String cat1;
	String cat2;
	String degree;
	String gender;
	private JComboBox sem;
	private JButton Home;
	
	
	
	
	private void clear_data()
	{
		Student_ID.setText("");
		Student_Name.setText("");
		Email_ID.setText("");
		Phone_No.setText("");
		Entry_Year.setText("");
		Caste.setText("");
		rd1.setSelected(false);
		rd2.setSelected(false);
		M.setSelected(false);
		F.setSelected(false);
		
		sem.setSelectedItem(false);
		
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student_Register frame = new Student_Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_Register() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 760, 631);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(95, 158, 160));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("STUDENT REGISTRATION");
		lblNewLabel.setFont(new Font("Serif", Font.BOLD, 21));
		lblNewLabel.setBounds(258, 70, 272, 46);
		contentPane.add(lblNewLabel);
		
		STUDENT_ID_2 = new JLabel("  Student ID:");
		STUDENT_ID_2.setFont(new Font("Serif", Font.BOLD, 17));
		STUDENT_ID_2.setBounds(10, 124, 138, 46);
		contentPane.add(STUDENT_ID_2);
		
		DEGREE_1 = new JLabel("  Degree Program:");
		DEGREE_1.setFont(new Font("Serif", Font.BOLD, 17));
		DEGREE_1.setBounds(10, 250, 150, 46);
		contentPane.add(DEGREE_1);
		
		JLabel STUDENT_NAME_1 = new JLabel("Student_Name:");
		STUDENT_NAME_1.setFont(new Font("Serif", Font.BOLD, 17));
		STUDENT_NAME_1.setBounds(388, 120, 138, 46);
		contentPane.add(STUDENT_NAME_1);
		
		EMAIL_ID_1 = new JLabel("Email ID:");
		EMAIL_ID_1.setFont(new Font("Serif", Font.BOLD, 17));
		EMAIL_ID_1.setBounds(20, 180, 84, 46);
		contentPane.add(EMAIL_ID_1);
		
		PHONE_NO_1 = new JLabel("Phone No.");
		PHONE_NO_1.setFont(new Font("Serif", Font.BOLD, 17));
		PHONE_NO_1.setBounds(388, 180, 138, 46);
		contentPane.add(PHONE_NO_1);
		
		SEMESTER_1 = new JLabel("Semester:");
		SEMESTER_1.setFont(new Font("Serif", Font.BOLD, 17));
		SEMESTER_1.setBounds(388, 250, 138, 46);
		contentPane.add(SEMESTER_1);
		
		JLabel GENDER_1 = new JLabel("  Gender:");
		GENDER_1.setFont(new Font("Serif", Font.BOLD, 17));
		GENDER_1.setBounds(10, 322, 138, 46);
		contentPane.add(GENDER_1);
		
		CASTE_1 = new JLabel("  Caste:");
		CASTE_1.setFont(new Font("Serif", Font.BOLD, 17));
		CASTE_1.setBounds(10, 392, 138, 46);
		contentPane.add(CASTE_1);
		
		JLabel ENTRY_YEAR_1 = new JLabel("Entry Year:");
		ENTRY_YEAR_1.setFont(new Font("Serif", Font.BOLD, 17));
		ENTRY_YEAR_1.setBounds(388, 322, 102, 46);
		contentPane.add(ENTRY_YEAR_1);
		
		Student_ID = new JTextField();
		Student_ID.setBackground(new Color(192, 192, 192));
		Student_ID.setBounds(158, 141, 73, 19);
		contentPane.add(Student_ID);
		Student_ID.setColumns(10);
		
		Email_ID = new JTextField();
		Email_ID.setBackground(new Color(192, 192, 192));
		Email_ID.setColumns(10);
		Email_ID.setBounds(158, 197, 188, 19);
		contentPane.add(Email_ID);
		
		Caste = new JTextField();
		Caste.setColumns(10);
		Caste.setBackground(Color.LIGHT_GRAY);
		Caste.setBounds(158, 409, 188, 19);
		contentPane.add(Caste);
		
		Student_Name = new JTextField();
		Student_Name.setColumns(10);
		Student_Name.setBackground(Color.LIGHT_GRAY);
		Student_Name.setBounds(512, 141, 188, 19);
		contentPane.add(Student_Name);
		
		Phone_No = new JTextField();
		Phone_No.setColumns(10);
		Phone_No.setBackground(Color.LIGHT_GRAY);
		Phone_No.setBounds(512, 197, 188, 19);
		contentPane.add(Phone_No);
		
		Entry_Year = new JTextField();
		Entry_Year.setColumns(10);
		Entry_Year.setBackground(Color.LIGHT_GRAY);
		Entry_Year.setBounds(512, 339, 188, 19);
		contentPane.add(Entry_Year);
		
		JButton add = new JButton("Save");
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					String STUDENT_ID=Student_ID.getText();
					String EMAIL_ID=Email_ID.getText();
			
					String CASTE=Caste.getText();
					//String REMAINING_FEES=Remaining_Fees.getText();
					String STUDENT_NAME=Student_Name.getText();
					String PHONE_NO=Phone_No.getText();
					String SEMESTER=(String) sem.getSelectedItem();
					String ENTRY_YEAR=Entry_Year.getText();
				
					
				if(rd1.isSelected()) {
					cat1="B.ED";
				}
				if(rd2.isSelected()) {
					cat1="D.ED";
				}
				if(M.isSelected()) {
					cat2="Male";
				}
				if(F.isSelected()) {
					cat2="Female";
				}
					
				String insert= db.Insert("insert into students_registration(STUDENT_ID, STUDENT_NAME, EMAIL_ID, PHONE_NO, DEGREE, SEMESTER, GENDER, ENTRY_YEAR, CASTE) values('"+STUDENT_ID+"','"+STUDENT_NAME+"','"+EMAIL_ID+"','"+PHONE_NO+"','"+cat1+"','"+SEMESTER+"','"+cat2+"','"+ENTRY_YEAR+"','"+CASTE+"')");
				JOptionPane.showMessageDialog(null, insert);
				clear_data();
				
				
	
				}catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, ex.toString());
				}
			}
		});
		add.setForeground(SystemColor.info);
		add.setBackground(new Color(0, 0, 0));
		add.setFont(new Font("Serif", Font.BOLD, 18));
		add.setBounds(171, 536, 90, 33);
		contentPane.add(add);
		
		JButton Update = new JButton("Reset");
		Update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				clear_data();
			}
		});
		Update.setForeground(SystemColor.info);
		Update.setBackground(new Color(0, 0, 0));
		Update.setFont(new Font("Serif", Font.BOLD, 18));
		Update.setBounds(349, 536, 96, 33);
		contentPane.add(Update);
		
		JButton Cancel = new JButton("Back");
		Cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IYearList obj=new IYearList ();
				obj.setVisible(true);
			}
		});
		Cancel.setForeground(new Color(255, 255, 255));
		Cancel.setBackground(new Color(0, 0, 0));
		Cancel.setFont(new Font("Serif", Font.BOLD, 18));
		Cancel.setBounds(530, 536, 90, 33);
		contentPane.add(Cancel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.inactiveCaption);
		panel_1.setBounds(20, 10, 73, 50);
		contentPane.add(panel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.inactiveCaption);
		panel.setBounds(103, 10, 598, 50);
		contentPane.add(panel);
		
		M = new JRadioButton("Male");
		M.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(M.isSelected()) {
					gender="Male";
					F.setSelected(false);
						
					}
			}
		});
		M.setBackground(new Color(192, 192, 192));
		M.setFont(new Font("Serif", Font.BOLD, 15));
		M.setBounds(158, 336, 73, 21);
		contentPane.add(M);
		
		F = new JRadioButton("Female");
		F.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(F.isSelected()) {
					gender="Female";
					M.setSelected(false);
						
					}
			}
		});
		F.setBackground(new Color(192, 192, 192));
		F.setFont(new Font("Serif", Font.BOLD, 15));
		F.setBounds(258, 336, 73, 21);
		contentPane.add(F);
		
		rd1 = new JRadioButton("B.ED");
		rd1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rd1.isSelected()) {
				degree="B.ED";
				rd2.setSelected(false);
					
				}
			}
		});
		rd1.setBackground(new Color(192, 192, 192));
		rd1.setFont(new Font("Serif", Font.BOLD, 15));
		rd1.setBounds(158, 264, 73, 21);
		contentPane.add(rd1);
		
		rd2 = new JRadioButton("D.ED");
		rd2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rd2.isSelected()) {
					degree="D.ED";
					rd1.setSelected(false);
						
					}
			}
		});
		rd2.setBackground(new Color(192, 192, 192));
		rd2.setFont(new Font("Serif", Font.BOLD, 15));
		rd2.setBounds(258, 264, 73, 21);
		contentPane.add(rd2);
		
		
		
		JButton btnNewButton = new JButton("search");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try

		          {

					 
				      String id=Student_ID.getText();
				      String name=Student_Name.getText();

					  
				      Class.forName("com.mysql.jdbc.Driver");

		              cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/college_fees_management","root","root");

		              st=cn.createStatement();

		              String sql = "select * from students_registration where STUDENT_ID = '"+id+"' or STUDENT_NAME='"+name+"'" ;

		              ResultSet rs=st.executeQuery(sql);

		              while(rs.next())

		              {

		                  Student_ID.setText(rs.getString("STUDENT_ID"));

		                  Student_Name.setText(rs.getString("STUDENT_NAME"));

		                  Email_ID.setText(rs.getString("EMAIL_ID"));

		                  Phone_No.setText(rs.getString("PHONE_NO"));

		                  Entry_Year.setText(rs.getString("ENTRY_YEAR"));

		                  Caste.setText(rs.getString("CASTE"));

		        
		                  

		              }

		          }

			
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(null, ex.toString());
				}
			}
		});
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 16));
		btnNewButton.setBounds(228, 140, 84, 21);
		contentPane.add(btnNewButton);
		
		sem = new JComboBox();
		sem.setFont(new Font("Serif", Font.BOLD, 16));
		sem.setModel(new DefaultComboBoxModel(new String[] {"Select semester", "Sem-I", "Sem-II", "Sem-III", "Sem-IV"}));
		sem.setBounds(514, 266, 186, 21);
		contentPane.add(sem);
		
		Home = new JButton("Home");
		Home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Home obj=new Home();
				obj.setVisible(true);
			}
		});
		Home.setForeground(Color.WHITE);
		Home.setFont(new Font("Serif", Font.BOLD, 15));
		Home.setBackground(Color.BLACK);
		Home.setBounds(627, 70, 73, 23);
		contentPane.add(Home);
	}
}
