import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JToggleButton;
import java.awt.Choice;
import java.awt.List;
import java.awt.Label;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class Home extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_2;
	private JTable table_3;
	private JTable table_4;
	private JRadioButton rd1;
	private JRadioButton rd2;
	
	String degree;	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 1400, 900);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(95, 158, 160));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Add student");
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(0, 0, 0));
		btnNewButton.setFont(new Font("Serif", Font.BOLD, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Student_Register obj=new Student_Register();
				obj.setVisible(true);
			}
		});
		btnNewButton.setBounds(501, 75, 126, 32);
		contentPane.add(btnNewButton);
		
		JList list = new JList();
		list.setBounds(47, 312, 105, -116);
		contentPane.add(list);
		
		table = new JTable();
		table.setBounds(166, 319, -100, -90);
		contentPane.add(table);
		
		table_2 = new JTable();
		table_2.setBounds(383, 369, -49, -140);
		contentPane.add(table_2);
		
		table_3 = new JTable();
		table_3.setBounds(333, 378, 0, -133);
		contentPane.add(table_3);
		
		table_4 = new JTable();
		table_4.setBounds(280, 410, -79, -151);
		contentPane.add(table_4);
		
		rd1 = new JRadioButton("B.ED");
		rd1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rd1.isSelected()) {
					degree="B.ED";
					rd2.setSelected(false);
						
					}
			}
		});
		rd1.setFont(new Font("Serif", Font.BOLD, 15));
		rd1.setBounds(166, 155, 73, 26);
		contentPane.add(rd1);
		
		rd2 = new JRadioButton("D.ED");
		rd2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(rd2.isSelected()) {
					degree="D.ED";
					rd1.setSelected(false);
						
					}
			}
		});
		rd2.setFont(new Font("Serif", Font.BOLD, 15));
		rd2.setBounds(417, 155, 73, 26);
		contentPane.add(rd2);
		
		JButton btnNewButton_1_1 = new JButton("Ist Year");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IYearList ob=new IYearList ();
				ob.setVisible(true);
				
				if(rd1.isSelected()) {

					IYearList obj =new IYearList();

					obj.setVisible(true);

					rd2.setSelected(false);

				}

				else {

					IDED obj =new IDED();

					obj.setVisible(true);

					rd1.setSelected(false);

				}
			}
		});
		btnNewButton_1_1.setForeground(new Color(245, 255, 250));
		btnNewButton_1_1.setFont(new Font("Serif", Font.PLAIN, 15));
		btnNewButton_1_1.setBackground(new Color(0, 0, 0));
		btnNewButton_1_1.setBounds(155, 213, 103, 32);
		contentPane.add(btnNewButton_1_1);
		
		JButton btnNewButton_2_1 = new JButton("IIst Year");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				IIYearList ob=new IIYearList ();
				ob.setVisible(true);
				
				if(rd1.isSelected()) {

					IIYearList obj =new IIYearList();

					obj.setVisible(true);

					rd2.setSelected(false);

				}

				else {

					IIDED obj =new IIDED();

					obj.setVisible(true);

					rd1.setSelected(false);

				}
			}
		});
		btnNewButton_2_1.setForeground(new Color(255, 240, 245));
		btnNewButton_2_1.setFont(new Font("Serif", Font.PLAIN, 15));
		btnNewButton_2_1.setBackground(new Color(0, 0, 0));
		btnNewButton_2_1.setBounds(408, 213, 103, 32);
		contentPane.add(btnNewButton_2_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(SystemColor.inactiveCaption);
		panel_1.setBounds(22, 10, 73, 50);
		contentPane.add(panel_1);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.inactiveCaption);
		panel.setBounds(105, 10, 597, 50);
		contentPane.add(panel);
		
		JLabel lblNewLabel = new JLabel("");
		ImageIcon img= new ImageIcon(this.getClass().getResource("home.jpg"));
		lblNewLabel.setIcon(img);
		lblNewLabel.setBounds(0, 0, 714, 595);
		contentPane.add(lblNewLabel);
		
		
		/*JLabel lblNewLabel = new JLabel("");
		ImageIcon img = new ImageIcon(this.getClass().getResource("/clg.jpeg"));
		lblNewLabel.setIcon(img);
		lblNewLabel.setBounds(0, 0, 714, 585);
		contentPane.add(lblNewLabel);*/
	}
}
